import express from 'express';
import { register, retriveall, updateOne } from './controller.js';
import { validateTask } from './validation.js';

const router= express.Router();

router.post("/register",validateTask,register)
router.get("/retriveall",retriveall)
router.put("/update",validateTask,updateOne)

export default router;