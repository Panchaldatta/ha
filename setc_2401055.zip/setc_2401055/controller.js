import taskModel from "./model.js"

export const register=async(req ,res)=>{
    try {
        const {title,description,status,id}=await req.body
        if(!title||!id){
            return res.status(400).json({message:"title and id fields are required"})
        }
        const task= await taskModel.findOne({id})
        if(task){
            return res.status(400).json({message:"task already exists"})
        }
        const newTask=await taskModel.create({title,description,status,id})

        return res.status(201).json({message:"task created successfully",newTask})
        
    } catch (error) {
        return res.status(500).json({message:error.message})
    }
}

export const retriveall=async(req,res)=>{
    try {
        const tasks=await taskModel.find();
        if(!tasks){
            return res.status(200).json({message:"there are no task in database"})
        }
        return res.status(200).json({tasks});
    } catch (error) {
        return res.status(500).json({message:error.message})
    }

}

export const updateOne=async(req,res)=>{
    try {
        const {title,description,status,id}=await req.body
        if(!title||!id){
            return res.status(400).json({message:"title and id fields are required"})
        }
        await taskModel.findOneAndUpdate({id},{$set:req.body})
        return res.status(201).json({message:"task updated successfully"})
    } catch (error) {
        return res.status(500).json({message:error.message})
    }
}