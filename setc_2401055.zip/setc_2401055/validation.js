import Joi from "joi";

const taskSchema=new Joi.object({
    id:Joi.number().required(),
    title:Joi.string().required().min(5),
    description:Joi.string().max(100),
    status:Joi.string().valid("pending","in-progress","completed"),
})

export const validateTask=async (req,res,next)=>{
    const{error}=taskSchema.validate(req.body)
    if(error){
        return res.status(400).json({message:error.details[0].message});
    }
    next();
}